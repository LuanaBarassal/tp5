package br.unisanta.tp3_listafilmes.controller

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.unisanta.tp3_listafilmes.R
import br.unisanta.tp3_listafilmes.view.FilmeAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ListaFilmesActivity : AppCompatActivity() {

    private lateinit var adapter: FilmeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_filmes)

        val recycler = findViewById<RecyclerView>(R.id.rvFilmes)
        val fabVoltar = findViewById<FloatingActionButton>(R.id.fabVoltar)

        adapter = FilmeAdapter(MainActivity.listaFilmes)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        fabVoltar.setOnClickListener { finish() }
    }
}
