package br.unisanta.tp3_listafilmes.controller

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import br.unisanta.tp3_listafilmes.R
import br.unisanta.tp3_listafilmes.model.Filme
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    companion object {
        val listaFilmes = mutableListOf<Filme>()
    }

    private lateinit var etTitulo: EditText
    private lateinit var cbAcao: CheckBox
    private lateinit var cbComedia: CheckBox
    private lateinit var cbDrama: CheckBox
    private lateinit var cbRomance: CheckBox
    private lateinit var cbFiccao: CheckBox
    private lateinit var seekAvaliacao: SeekBar
    private lateinit var tvAvaliacao: TextView
    private lateinit var btnAdicionar: Button
    private lateinit var fabVerLista: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etTitulo = findViewById(R.id.etTitulo)
        cbAcao = findViewById(R.id.cbAcao)
        cbComedia = findViewById(R.id.cbComedia)
        cbDrama = findViewById(R.id.cbDrama)
        cbRomance = findViewById(R.id.cbRomance)
        cbFiccao = findViewById(R.id.cbFiccao)
        seekAvaliacao = findViewById(R.id.seekAvaliacao)
        tvAvaliacao = findViewById(R.id.tvAvaliacao)
        btnAdicionar = findViewById(R.id.btnAdicionar)
        fabVerLista = findViewById(R.id.fabVerLista)

        seekAvaliacao.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvAvaliacao.text = progress.toString()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnAdicionar.setOnClickListener {
            val titulo = etTitulo.text.toString().trim()
            val avaliacao = seekAvaliacao.progress
            val generos = mutableListOf<String>()

            if (cbAcao.isChecked) generos.add("Ação")
            if (cbComedia.isChecked) generos.add("Comédia")
            if (cbDrama.isChecked) generos.add("Drama")
            if (cbRomance.isChecked) generos.add("Romance")
            if (cbFiccao.isChecked) generos.add("Ficção")

            if (titulo.isEmpty()) {
                Toast.makeText(this, "Informe o título do filme!", Toast.LENGTH_SHORT).show()
            } else {
                val filme = Filme(titulo, generos, avaliacao)
                listaFilmes.add(filme)
                Toast.makeText(this, "Filme adicionado!", Toast.LENGTH_SHORT).show()
                etTitulo.text.clear()
                seekAvaliacao.progress = 5
                tvAvaliacao.text = "5"
                cbAcao.isChecked = false
                cbComedia.isChecked = false
                cbDrama.isChecked = false
                cbRomance.isChecked = false
                cbFiccao.isChecked = false
            }
        }

        fabVerLista.setOnClickListener {
            val intent = Intent(this, ListaFilmesActivity::class.java)
            startActivity(intent)
        }
    }
}
