package br.unisanta.tp3_listafilmes.model

data class Filme(
    val titulo: String,
    val generos: List<String>,
    val avaliacao: Int
) {
    fun generosFormatados(): String =
        if (generos.isEmpty()) "Sem gênero" else generos.joinToString(", ")
}
