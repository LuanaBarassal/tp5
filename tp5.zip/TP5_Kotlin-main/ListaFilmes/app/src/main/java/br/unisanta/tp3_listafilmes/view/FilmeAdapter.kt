package br.unisanta.tp3_listafilmes.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.unisanta.tp3_listafilmes.R
import br.unisanta.tp3_listafilmes.model.Filme

class FilmeAdapter(private val listaFilmes: MutableList<Filme>) :
    RecyclerView.Adapter<FilmeAdapter.FilmeViewHolder>() {

    class FilmeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titulo: TextView = itemView.findViewById(R.id.tvTitulo)
        val generos: TextView = itemView.findViewById(R.id.tvGeneros)
        val avaliacao: TextView = itemView.findViewById(R.id.tvAvaliacao)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_filme, parent, false)
        return FilmeViewHolder(view)
    }

    override fun onBindViewHolder(holder: FilmeViewHolder, position: Int) {
        val filme = listaFilmes[position]
        holder.titulo.text = filme.titulo
        holder.generos.text = "Gêneros: ${filme.generosFormatados()}"
        holder.avaliacao.text = "Avaliação: ${filme.avaliacao}/10"
    }

    override fun getItemCount() = listaFilmes.size
}
