package br.unisanta.registrartarefa.controller

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.unisanta.registrartarefa.R
import br.unisanta.registrartarefa.view.TarefaAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ListaTarefasActivity : AppCompatActivity() {

    private lateinit var adapter: TarefaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_tarefas)

        val recycler = findViewById<RecyclerView>(R.id.rvTarefas)
        recycler.layoutManager = LinearLayoutManager(this)

        adapter = TarefaAdapter(MainActivity.listaTarefas)
        recycler.adapter = adapter

        val fabVoltar = findViewById<FloatingActionButton>(R.id.fabVoltar)
        fabVoltar.setOnClickListener { finish() }
    }
}
