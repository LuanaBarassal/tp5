package br.unisanta.registrartarefa.controller

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import br.unisanta.registrartarefa.R
import br.unisanta.registrartarefa.model.Tarefa
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    companion object {
        val listaTarefas = mutableListOf<Tarefa>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNome = findViewById<EditText>(R.id.etNome)
        val etDescricao = findViewById<EditText>(R.id.etDescricao)
        val spStatus = findViewById<Spinner>(R.id.spStatus)
        val btnAdicionar = findViewById<Button>(R.id.btnAdicionar)
        val fabVerTarefas = findViewById<FloatingActionButton>(R.id.fabVerTarefas)

        // Opções do Spinner
        val adapterSpinner = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            listOf("Pendente", "Em andamento", "Concluída")
        )
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spStatus.adapter = adapterSpinner

        btnAdicionar.setOnClickListener {
            val nome = etNome.text.toString().trim()
            val descricao = etDescricao.text.toString().trim()
            val status = spStatus.selectedItem.toString()

            if (nome.isEmpty()) {
                Toast.makeText(this, "Informe o nome da tarefa", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            listaTarefas.add(Tarefa(nome, descricao, status))
            Toast.makeText(this, "Tarefa adicionada", Toast.LENGTH_SHORT).show()

            etNome.text.clear()
            etDescricao.text.clear()
            spStatus.setSelection(0)
        }

        fabVerTarefas.setOnClickListener {
            startActivity(Intent(this, ListaTarefasActivity::class.java))
        }
    }
}
