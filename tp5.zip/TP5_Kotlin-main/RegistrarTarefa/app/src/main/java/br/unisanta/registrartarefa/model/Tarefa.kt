package br.unisanta.registrartarefa.model

data class Tarefa(
    val nome: String,
    val descricao: String,
    var status: String = "Pendente",
    var concluida: Boolean = false
)
