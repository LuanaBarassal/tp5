package br.unisanta.registrartarefa.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.unisanta.registrartarefa.R
import br.unisanta.registrartarefa.model.Tarefa

class TarefaAdapter(private val tarefas: List<Tarefa>) :
    RecyclerView.Adapter<TarefaAdapter.TarefaViewHolder>() {

    inner class TarefaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nome = view.findViewById<TextView>(R.id.tvNome)
        val descricao = view.findViewById<TextView>(R.id.tvDescricao)
        val status = view.findViewById<TextView>(R.id.tvStatus)
        val btnConcluir = view.findViewById<Button>(R.id.btnConcluir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TarefaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tarefa, parent, false)
        return TarefaViewHolder(view)
    }

    override fun getItemCount() = tarefas.size

    override fun onBindViewHolder(holder: TarefaViewHolder, position: Int) {
        val tarefa = tarefas[position]

        holder.nome.text = tarefa.nome
        holder.descricao.text = tarefa.descricao
        holder.status.text = "Status: ${tarefa.status}"

        when (tarefa.status) {
            "Pendente" -> {
                holder.btnConcluir.text = "Iniciar"
                holder.btnConcluir.isEnabled = true
                holder.btnConcluir.setBackgroundColor(0xFF800080.toInt())
                holder.btnConcluir.setOnClickListener {
                    tarefa.status = "Em andamento"
                    notifyItemChanged(position)
                }
            }
            "Em andamento" -> {
                holder.btnConcluir.text = "Concluir"
                holder.btnConcluir.isEnabled = true
                holder.btnConcluir.setBackgroundColor(0xFF008000.toInt())
                holder.btnConcluir.setOnClickListener {
                    tarefa.status = "Concluída"
                    tarefa.concluida = true
                    notifyItemChanged(position)
                }
            }
            "Concluída" -> {
                holder.btnConcluir.text = "Concluída"
                holder.btnConcluir.isEnabled = false
                holder.btnConcluir.setBackgroundColor(0xFF757575.toInt())
            }
        }
    }
}
